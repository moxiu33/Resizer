# 当SKIPUNZIP=1时跳过默认的解压程序和设置权限过程
SKIPUNZIP=0

# 当REPLACE里设置了路径变量，会删除此目录，路径中不能有空格和特殊符号
# 例如这将删除/system/app/test目录
# REPLACE="/system/app/test"

# 请尽量使用ui_print代替echo，因为echo的信息不会在TWRP恢复下显示
# 开始自由编写shell代码
