#!/system/bin/sh
# 请尽量使用$MODDIR获取本模块路径，即使Magisk将来更改挂载路径也依然有效
# 编写你的shell脚本，service.sh是和开机并行运行的，可写死循环脚本
MODDIR=${0%/*}

